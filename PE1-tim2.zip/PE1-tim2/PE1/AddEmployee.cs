﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PE1
{
    public partial class AddEmployee : Form
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string insertCmd1 = "INSERT INTO Employee (Name, Login, PositionEmployeeId, StatusEmployeeId, DivisionId, Password) VALUES ('@Name', '@Login', '@PositionEmployeeId', '@StatusEmployeeId', '@DivisionId', '@Password')";

            //string insertCmd1 = "INSERT INTO Employee (Name, Login, PositionEmployeeId, StatusEmployeeId, DivisionId, Password) VALUES ('"+ textBox1.Text +"', '"+ textBox2.Text +"', "+ Convert.ToInt32(textBox3.Text) + ", " + Convert.ToInt32(textBox4.Text) + ", " + Convert.ToInt32(textBox5.Text) + ", '"+ textBox6.Text +"')";


            DB db = new DB();

            using (SqlConnection connection = new SqlConnection("Data Source=(LocalDb)\\MSSQLLocalDB;Initial Catalog=ExampleDB;Integrated Security=SSPI;"))
            {

                try
                {
                    connection.Open();
                    string insertCmd = "INSERT INTO Employee (Name, Login, PositionEmployeeId, StatusEmployeeId, DivisionId, Password) VALUES ('" + textBox1.Text + "', '" + textBox2.Text + "', " + Convert.ToInt32(textBox3.Text) + ", " + Convert.ToInt32(textBox4.Text) + ", " + Convert.ToInt32(textBox5.Text) + ", '" + textBox6.Text + "')";

                    SqlCommand cmd = new SqlCommand(insertCmd, connection);
                    if (cmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("Запись успешно добавлена.");
                    connection.Close();
                    Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                /*connection.Open();
                SqlCommand myCommand1 = new SqlCommand(insertCmd1, connection);
                myCommand1.Parameters.AddWithValue("@Name", Convert.ToString(textBox1.Text));
                myCommand1.ExecuteNonQuery();

                SqlCommand myCommand2 = new SqlCommand(insertCmd1, connection);
                myCommand2.Parameters.AddWithValue("@Login", Convert.ToString(textBox2.Text));
                myCommand2.ExecuteNonQuery();

                SqlCommand myCommand3 = new SqlCommand(insertCmd1, connection);
                myCommand3.Parameters.AddWithValue("@PositionEmployeeId", Convert.ToInt32(textBox3.Text));
                myCommand3.ExecuteNonQuery();

                SqlCommand myCommand4 = new SqlCommand(insertCmd1, connection);
                myCommand4.Parameters.AddWithValue("@StatusEmployeeId", Convert.ToInt32(textBox4.Text));
                myCommand4.ExecuteNonQuery();

                SqlCommand myCommand5 = new SqlCommand(insertCmd1, connection);
                myCommand5.Parameters.AddWithValue("@DivisionId", Convert.ToInt32(textBox5.Text));
                myCommand5.ExecuteNonQuery();

                SqlCommand myCommand6 = new SqlCommand(insertCmd1, connection);
                myCommand6.Parameters.AddWithValue("@Password", Convert.ToString(textBox6.Text));
                myCommand6.ExecuteNonQuery();*/
            }
        }

        private void AddEmployee_Load(object sender, EventArgs e)
        {

        }
    }
}
