﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PE1
{
    public partial class DeleteEmployee : Form
    {
        public DeleteEmployee()
        {
            InitializeComponent();
        }

        private void DeleteEmployee_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //var cmd = new SqlCommand(String.Format("UPDATE Country SET [country]='{0}'WHERE id ={1}"Country.Text, id1));
            //var cmd = new SqlCommand("UPDATE Country SET [country]=@country WHERE id =@id");

            DB db = new DB();

            using (SqlConnection connection = new SqlConnection("Data Source=(LocalDb)\\MSSQLLocalDB;Initial Catalog=ExampleDB;Integrated Security=SSPI;"))
            {

                try
                {
                    connection.Open();
                    string updateCmd = "UPDATE Employee SET [StatusEmployeeId]=" + Convert.ToInt32(textBox3.Text) + " where Name = '" + textBox1.Text + "' and Login = '" + textBox2.Text + "'";

                    SqlCommand cmd = new SqlCommand(updateCmd, connection);
                    if (cmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("Статус работника успешно обнавлен.");
                    connection.Close();
                    Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
